# 🔥 TIREX STORE V8 — Build Guide (FIXED)

## ✅ Perubahan Fix di versi ini:
- Gradle 7.5 → 7.6.3 (lebih stabil)
- AGP 7.3.0 → 7.4.2
- Kotlin 1.7.10 → 1.8.22
- Java 8 → 11 (kompatibel Flutter 3.x)
- JVM args optimized (build lebih cepat)
- Parallel build & caching diaktifkan

## ⚡ Build Cepat (untuk BOT / CI):

### Wajib set sebelum build:
```bash
export FLUTTER_SDK=/path/to/flutter
echo "flutter.sdk=$FLUTTER_SDK" >> android/local.properties
```

### Build command:
```bash
flutter pub get && flutter build apk --release --no-tree-shake-icons
```

### APK output:
```
build/app/outputs/flutter-apk/app-release.apk
```

## 🤖 Jika pakai BOT BUILD APK:
Upload ZIP ini langsung. Bot akan otomatis detect `flutter.sdk` dari environment.

## 📌 Setup API Key (opsional):
Edit `lib/main.dart`, cari:
```dart
static const _apiKey = 'YOUR_ANTHROPIC_API_KEY';
```
Ganti dengan key dari https://console.anthropic.com
