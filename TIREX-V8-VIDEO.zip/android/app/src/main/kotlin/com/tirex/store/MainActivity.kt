package com.tirex.store

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
