import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

void main() {
  runApp(const TirexStoreApp());
}

class TirexStoreApp extends StatelessWidget {
  const TirexStoreApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'TIREX STORE',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFFFD700),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFF050505),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  Future<void> _launchUrl(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF050505),
      body: SingleChildScrollView(
        child: Column(
          children: [
            _buildHero(),
            _buildTikTokVideo(),
            _buildServices(),
            _buildContact(),
            _buildFooter(),
          ],
        ),
      ),
    );
  }

  Widget _buildHero() {
    return Container(
      width: double.infinity,
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF1a1500), Color(0xFF050505)],
        ),
      ),
      child: Column(
        children: [
          const SizedBox(height: 20),
          Container(
            height: 3,
            decoration: const BoxDecoration(
              gradient: LinearGradient(colors: [
                Colors.transparent, Color(0xFFFFD700), Colors.white, Color(0xFFFFD700), Colors.transparent,
              ]),
            ),
          ),
          const SizedBox(height: 36),
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 24),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(color: const Color(0xFFFFD700).withOpacity(0.4), blurRadius: 30, spreadRadius: 2),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.asset('assets/logo.jpg', fit: BoxFit.contain),
            ),
          ),
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
            decoration: BoxDecoration(
              border: Border.all(color: const Color(0xFFFFD700).withOpacity(0.5)),
              borderRadius: BorderRadius.circular(3),
              color: const Color(0xFFFFD700).withOpacity(0.07),
            ),
            child: const Text('⚡  REGION JAWA TIMUR  ⚡',
                style: TextStyle(color: Color(0xFFFFD700), fontSize: 12, fontWeight: FontWeight.w800, letterSpacing: 4)),
          ),
          const SizedBox(height: 14),
          const Text('Solusi Digital Terpercaya · Harga Terjangkau · Respon Cepat',
              textAlign: TextAlign.center,
              style: TextStyle(color: Color(0xFF888888), fontSize: 12, letterSpacing: 2)),
          const SizedBox(height: 32),
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 40),
            height: 1,
            decoration: const BoxDecoration(
              gradient: LinearGradient(colors: [
                Colors.transparent, Color(0xFFFFD700), Colors.white, Color(0xFFFFD700), Colors.transparent,
              ]),
            ),
          ),
          const SizedBox(height: 40),
        ],
      ),
    );
  }

  Widget _buildTikTokVideo() {
    final controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF050505))
      ..loadRequest(Uri.parse(
        'https://www.tiktok.com/embed/v2/7498060959338196230',
      ));

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: const [
              Text('🎵', style: TextStyle(fontSize: 18)),
              SizedBox(width: 8),
              Text('VIDEO TERBARU',
                  style: TextStyle(
                      color: Color(0xFFFFD700),
                      fontSize: 14,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 3)),
              SizedBox(width: 8),
              Text('🎵', style: TextStyle(fontSize: 18)),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            height: 560,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFF333333)),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: WebViewWidget(controller: controller),
            ),
          ),
          const SizedBox(height: 8),
          GestureDetector(
            onTap: () async {
              final uri = Uri.parse('https://vt.tiktok.com/ZS9NHoB6Ere97-vwgjd/');
              if (await canLaunchUrl(uri)) {
                await launchUrl(uri, mode: LaunchMode.externalApplication);
              }
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              decoration: BoxDecoration(
                color: const Color(0xFF111111),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: const Color(0xFF333333)),
              ),
              child: const Text('▶ Buka di TikTok',
                  style: TextStyle(color: Color(0xFF888888), fontSize: 12, letterSpacing: 1)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildServices() {
    final services = [
      {'icon': '📱', 'num': '01', 'title': 'APK GACOR WA', 'desc': 'Aplikasi WhatsApp modifikasi fitur lengkap, performa optimal.', 'spotify': 'false'},
      {'icon': '🎨', 'num': '02', 'title': 'MURID BAND WP', 'desc': 'Wallpaper & tema eksklusif desain premium untuk WhatsApp.', 'spotify': 'false'},
      {'icon': '🖼️', 'num': '03', 'title': 'MURID LOGO', 'desc': 'Koleksi logo siap pakai untuk berbagai kebutuhan media sosial.', 'spotify': 'false'},
      {'icon': '🔢', 'num': '04', 'title': 'MURID NOKOS', 'desc': 'Nomor kosong berbagai pilihan untuk kebutuhan akun digital.', 'spotify': 'false'},
      {'icon': '✏️', 'num': '05', 'title': 'JASA BUATIN LOGO', 'desc': 'Desain logo custom profesional sesuai permintaan, cepat & berkualitas.', 'spotify': 'false'},
      {'icon': '⚽', 'num': '06', 'title': 'JASTIP PARLAY', 'desc': 'Layanan jasa titip parlay dengan admin berpengalaman dan terpercaya.', 'spotify': 'false'},
      {'icon': '📞', 'num': '07', 'title': 'SEWA WA', 'desc': 'Sewa nomor WhatsApp aktif untuk berbagai keperluan.', 'spotify': 'false'},
      {'icon': '🎵', 'num': '08', 'title': 'SPOTIFY PREMIUM', 'desc': 'Akun Spotify Premium individual & family. Musik tanpa batas, tanpa iklan.', 'spotify': 'true'},
      {'icon': '🎧', 'num': '09', 'title': 'MURID PLAYLIST', 'desc': 'Koleksi playlist Spotify siap pakai berbagai genre.', 'spotify': 'true'},
      {'icon': '🎤', 'num': '10', 'title': 'JASA UPGRADE SPOTIFY', 'desc': 'Upgrade akun Spotify kamu ke Premium dengan harga terjangkau.', 'spotify': 'true'},
    ];

    final List<Widget> cards = [];
    bool spotifyHeaderAdded = false;

    for (final s in services) {
      if (s['spotify'] == 'true' && !spotifyHeaderAdded) {
        spotifyHeaderAdded = true;
        cards.add(const SizedBox(height: 20));
        cards.add(Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
          decoration: BoxDecoration(
            color: const Color(0xFF1DB954).withOpacity(0.08),
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: const Color(0xFF1DB954).withOpacity(0.3)),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: const [
              Text('🎵', style: TextStyle(fontSize: 18)),
              SizedBox(width: 10),
              Text('SPOTIFY SERVICES',
                  style: TextStyle(color: Color(0xFF1DB954), fontSize: 13, fontWeight: FontWeight.w900, letterSpacing: 4)),
              SizedBox(width: 10),
              Text('🎵', style: TextStyle(fontSize: 18)),
            ],
          ),
        ));
        cards.add(const SizedBox(height: 16));
      }
      cards.add(_ServiceCard(
        icon: s['icon']!,
        num: s['num']!,
        title: s['title']!,
        desc: s['desc']!,
        accent: s['spotify'] == 'true' ? const Color(0xFF1DB954) : const Color(0xFFFFD700),
      ));
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 40),
      child: Column(
        children: [
          RichText(
            text: const TextSpan(children: [
              TextSpan(text: 'LAYANAN ', style: TextStyle(color: Colors.white, fontSize: 36, fontWeight: FontWeight.w900, letterSpacing: 4)),
              TextSpan(text: 'KAMI', style: TextStyle(color: Color(0xFFFFD700), fontSize: 36, fontWeight: FontWeight.w900, letterSpacing: 4)),
            ]),
          ),
          const SizedBox(height: 6),
          const Text('TIREX STR MENYEDIAKAN', style: TextStyle(color: Color(0xFF888888), fontSize: 11, letterSpacing: 4)),
          const SizedBox(height: 28),
          ...cards,
        ],
      ),
    );
  }

  Widget _buildContact() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 50, horizontal: 20),
      decoration: const BoxDecoration(
        border: Border(top: BorderSide(color: Color(0xFF222222))),
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF050505), Color(0xFF0d0d0d)],
        ),
      ),
      child: Column(
        children: [
          RichText(
            text: const TextSpan(children: [
              TextSpan(text: 'HUBUNGI ', style: TextStyle(color: Colors.white, fontSize: 34, fontWeight: FontWeight.w900, letterSpacing: 4)),
              TextSpan(text: 'ADMIN', style: TextStyle(color: Color(0xFFFFD700), fontSize: 34, fontWeight: FontWeight.w900, letterSpacing: 4)),
            ]),
          ),
          const SizedBox(height: 6),
          const Text('SIAP MELAYANI 24 JAM', style: TextStyle(color: Color(0xFF888888), fontSize: 11, letterSpacing: 4)),
          const SizedBox(height: 28),
          _ContactButton(label: 'WhatsApp Admin', color: const Color(0xFF128C7E), icon: Icons.chat,
              onTap: () => _launchUrl('https://wa.me/6289672878807')),
          const SizedBox(height: 12),
          _ContactButton(label: 'Telegram Admin', color: const Color(0xFF0088cc), icon: Icons.send,
              onTap: () => _launchUrl('https://t.me/TIREXNOTDEV')),
          const SizedBox(height: 12),
          _ContactButton(label: 'TikTok Admin', color: const Color(0xFF111111), icon: Icons.music_note,
              onTap: () => _launchUrl('https://tiktok.com/@tirex_str'), border: true),
          const SizedBox(height: 12),
          _ContactButton(
            label: 'Order Spotify Premium 🎵',
            color: const Color(0xFF1DB954),
            icon: Icons.headphones,
            onTap: () => _launchUrl('https://wa.me/6289672878807?text=Halo+admin+TIREX+STORE%2C+mau+order+Spotify+Premium'),
          ),
          const SizedBox(height: 20),
          const Text('+62 896-7287-8807', style: TextStyle(color: Color(0xFF444444), fontSize: 13, letterSpacing: 3)),
        ],
      ),
    );
  }

  Widget _buildFooter() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 20),
      decoration: const BoxDecoration(
        border: Border(top: BorderSide(color: Color(0xFF222222))),
        color: Color(0xFF050505),
      ),
      child: RichText(
        textAlign: TextAlign.center,
        text: const TextSpan(
          style: TextStyle(fontSize: 11, letterSpacing: 2, color: Color(0xFF333333)),
          children: [
            TextSpan(text: '© 2026 '),
            TextSpan(text: 'TIREX STORE', style: TextStyle(color: Color(0xFFFFD700))),
            TextSpan(text: ' · REGION JAWA TIMUR'),
          ],
        ),
      ),
    );
  }
}

class _ServiceCard extends StatefulWidget {
  final String icon, num, title, desc;
  final Color accent;
  const _ServiceCard({required this.icon, required this.num, required this.title, required this.desc,
      this.accent = const Color(0xFFFFD700)});
  @override
  State<_ServiceCard> createState() => _ServiceCardState();
}

class _ServiceCardState extends State<_ServiceCard> {
  bool _hovered = false;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _hovered = true),
      onTapUp: (_) => setState(() => _hovered = false),
      onTapCancel: () => setState(() => _hovered = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: const Color(0xFF111111),
          borderRadius: BorderRadius.circular(6),
          border: Border.all(
              color: _hovered ? widget.accent.withOpacity(0.4) : const Color(0xFF222222)),
          boxShadow: _hovered
              ? [BoxShadow(color: widget.accent.withOpacity(0.1), blurRadius: 20, spreadRadius: 2)]
              : [],
        ),
        child: Row(
          children: [
            Text(widget.icon, style: const TextStyle(fontSize: 28)),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(widget.title,
                          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 14, letterSpacing: 1)),
                      Text(widget.num,
                          style: TextStyle(color: widget.accent.withOpacity(0.4), fontSize: 10, letterSpacing: 2)),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(widget.desc,
                      style: const TextStyle(color: Color(0xFF888888), fontSize: 12, height: 1.5)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ContactButton extends StatelessWidget {
  final String label;
  final Color color;
  final IconData icon;
  final VoidCallback onTap;
  final bool border;
  const _ContactButton({required this.label, required this.color, required this.icon,
      required this.onTap, this.border = false});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        onPressed: onTap,
        icon: Icon(icon, size: 20),
        label: Text(label,
            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, letterSpacing: 2)),
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(5),
            side: border ? const BorderSide(color: Color(0xFF444444)) : BorderSide.none,
          ),
        ),
      ),
    );
  }
}
